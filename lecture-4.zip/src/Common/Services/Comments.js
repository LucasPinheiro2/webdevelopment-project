import Parse from "parse";
/* SERVICE FOR PARSE SERVER OPERATIONS */

// CREATE OPERATION
// DatePreference class
export const createComments = (Text, Preference) => {
  const Comment = Parse.Object.extend("Comment");
  const comment = new Comment(); //create new datePreference object
  //use setter to UPDATE parameters of datePreference object
  comment.set("text", Text);
  comment.set("preference", Preference);
  return comment.save().then((result) => {
    return result; // returns new datePreference object
  });
};

// READ OPERATION BY ID
// get single comment by ID
export const getById = (id) => {
  const Comment = Parse.Object.extend("Comment");
  const query = new Parse.Query(Comment);
  return query.get(id).then((result) => {
    // return DatePreference object with matching id only
    return result;
  });
};

// READ OPERATION ALL
// get all comments in Parse class Comment
export const getAllComments = (Preference) => {
  const Comment = Parse.Object.extend("Comment");
  const query = new Parse.Query(Comment);
  query.equalTo("preference", Preference);
  return query.find().then((results) => {
    return results; // returns array of comment objects
  });
};
