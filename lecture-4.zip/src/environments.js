module.exports = {
  APPLICATION_ID: "VWMcUoP8HLPsD1XyizoEUotTK9P0sd0slreJ6IX9",
  JAVASCRIPT_KEY: "0oebGVi4Lm2H8tgzk0NHinLak3XQWWnbGSNVnVW4",
  SERVER_URL: "https://parseapi.back4app.com/"
};
