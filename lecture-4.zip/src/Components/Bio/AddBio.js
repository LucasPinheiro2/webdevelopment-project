import React from "react";

/* STATELESS CHILD COMPONENT */
const AddBio = ({
  onClick,
  onChangeOwnerName,
  onChangeDogName,
  onChangeDogBreed,
  onChangeEmail
}) => {
  /* Add Doggy Profile section with form */
  return (
    <div>
      <hr />
      <h3>Add a Doggy Profile:</h3>
      <p>This will be displayed to other users for offline connection</p>
      <form>
        Owner Name: <input text="ownerName" onChange={onChangeOwnerName} />{" "}
        <br />
        Dog Name: <input text="dogName" onChange={onChangeDogName} /> <br />
        Dog Breed: <input text="dogBreed" onChange={onChangeDogBreed} /> <br />
        Email: <input type="email" text="email" onChange={onChangeEmail} />{" "}
        <br />
        <br />
        <button type="submit" onClick={onClick}>
          Add Bio
        </button>
      </form>
    </div>
  );
};

export default AddBio; /* export STATELESS child component - events up*/
