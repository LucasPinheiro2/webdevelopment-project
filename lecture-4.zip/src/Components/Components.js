import React from "react";
import ScheduleDatesModule from "./DoggyDates/ScheduleDates.js";
import BioModule from "./Bio/Bio.js";
import PreferencesModule from "./DatePreferences/Preferences.js";

const Components = () => {
  return (
    <div>
      {/*Call Class Main Modules */}
      <ScheduleDatesModule />
      <BioModule />
      <PreferencesModule />
    </div>
  );
};

export default Components;
