import React, { useEffect, useState } from "react";
import {
  createComments,
  getById,
  getAllComments
} from "./../../Common/Services/Comments";
import AddComments from "./AddComments";

/* STATEFUL PARENT COMPONENT */
const CommentList = ({ pref }) => {
  // Variables in the state to hold data
  const [comments, setComments] = useState([]);
  const [text, setText] = useState();
  const [preference, setPreference] = useState();
  //const [prefId, setPrefId] = useState();

  // UseEffect to run when the page loads to obtain ASYNC data and render
  useEffect(() => {
    // set  list to display all comments
    getAllComments(pref).then((comments) => {
      setComments(comments);
    });
    getById(preference).then((comment) => {
      setComments(comment);
    });
  }, [pref, preference]);

  // Flags in the state to watch for add/remove updates
  const [add, setAdd] = useState(false);

  // UseEffect that runs when changes are made to the state variables/flags
  useEffect(() => {
    // Check for add flag and make sure name state variable is defined
    if (text && add) {
      createComments(text, preference).then((newComment) => {
        setAdd(false);
        // Add the newly created preference to the preferences array to render the new list of preferences
        setComments([...comments, newComment]);
      });
    }
  }, [text, add, comments, preference]);

  // Handler to handle event passed from child submit button
  const onClickHandler = (e) => {
    e.preventDefault();
    setAdd(true); // Trigger add flag to create comment and re-render list with new preference
  };

  // Handlers to track changes to the child input  text
  const onChangeTextHandler = (e) => {
    e.preventDefault();
    setPreference(pref);
    setText(e.target.value); // Continuously updating ownerName to be added on submit
  };

  return (
    // Display preferences information in list for view
    <div>
      <div id="comments">
        {comments.length > 0 && (
          <ul>
            {comments.map((comment) => (
              <div>
                <span>
                  <li key={comment.id}>
                    <b>Comment: </b>
                    {comment.get("text")}
                  </li>
                </span>
              </div>
            ))}
          </ul>
        )}
      </div>
      {/* Stateless Child component passing up events from form */}
      <AddComments
        onClick={onClickHandler}
        onChangeText={onChangeTextHandler}
      />
    </div>
  );
};

export default CommentList;
