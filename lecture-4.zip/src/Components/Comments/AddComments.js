import React from "react";

/* STATELESS CHILD COMPONENT */
const AddComments = ({ onChangeText, onClick}) => {
  return (
    /* Add Doggy Date section with form */
    <div>
      <form>
        Comment <input text="comment" onChange={onChangeText} /> <br />
        <button type="submit" onClick={onClick}>
          Post Comment
        </button>
      </form>
    </div>
  );
};

export default AddComments; /* export STATELESS child component - events up*/
