import React from "react";
import DatesList from "./DatesList";

/* MAIN MODULE WITH STATEFUL PARENT AND STATELESS CHILD */
const ScheduleDatesModule = () => {
  return (
    <div>
      <h2>Upcoming Events:</h2>
      <DatesList /> {/* Call STATEFUL Parent*/}
    </div>
  );
};

export default ScheduleDatesModule;
