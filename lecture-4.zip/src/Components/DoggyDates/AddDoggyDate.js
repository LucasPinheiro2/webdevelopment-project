import React from "react";

/* STATELESS CHILD COMPONENT */
const AddDoggyDate = ({ onChangeName, onChangeDay, onChangeTime, onClick }) => {
  return (
    /* Add Doggy Date section with form */
    <div>
      <hr />
      <h3>Add a Doggy Date:</h3>
      <form>
        Name: <input text="name" onChange={onChangeName} /> <br />
        Date: <input type="date" text="day" onChange={onChangeDay} /> <br />
        Time: <input type="time" text="time" onChange={onChangeTime} /> <br />
        <br />
        <button type="submit" onClick={onClick}>
          Add Doggy Date
        </button>
      </form>
    </div>
  );
};

export default AddDoggyDate; /* export STATELESS child component - events up*/
