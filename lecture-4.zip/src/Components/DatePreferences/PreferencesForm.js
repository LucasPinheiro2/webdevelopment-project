import React from "react";

/* STATELESS CHILD COMPONENT */
const AddDatePreference = ({
  onChangeName,
  onChangePlace,
  onChangeWeather,
  onChangePeriod,
  onClick
}) => {
  return (
    /* Add Doggy Date section with form */
    <div>
      <hr />
      <h3>Choose your date preferences:</h3>
      <form>
        Owner's name: <input text="name" onChange={onChangeName} /> <br />
        Preferred place: <input text="place" onChange={onChangePlace} /> <br />
        Preferred weather: <input
          text="weather"
          onChange={onChangeWeather}
        />{" "}
        <br />
        Preferred period: <input text="period" onChange={onChangePeriod} />{" "}
        <br />
        <br />
        <button type="submit" onClick={onClick}>
          Add Preferences
        </button>
      </form>
    </div>
  );
};

export default AddDatePreference; /* export STATELESS child component - events up*/
